// FAQ accordion: the browser handles the clicked item's toggle; when one opens, close every other item.
document.addEventListener('DOMContentLoaded',function(){
  const faqItems=[...document.querySelectorAll('.d2-faq details')];
  faqItems.forEach(function(item){
    item.addEventListener('toggle',function(){
      if(!item.open) return;
      faqItems.forEach(function(other){
        if(other!==item) other.open=false;
      });
    });
  });
});

/* ---- next script block ---- */

document.getElementById('askQuestionForm')?.addEventListener('submit',function(e){e.preventDefault();const name=document.getElementById('askQuestionName').value.trim();const phone=document.getElementById('askQuestionPhone').value.trim();const email=document.getElementById('askQuestionEmail').value.trim();const q=document.getElementById('askQuestionInput').value.trim();if(!name||!phone||!q)return;const msg='*New Customer Question*\n\nName: '+name+'\nMobile: '+phone+(email?'\nEmail: '+email:'')+'\nQuestion: '+q;window.location.href='https://wa.me/918889633535?text='+encodeURIComponent(msg);});

/* ---- next script block ---- */

// Robust single-open accordion: opening one FAQ always closes every other FAQ.
document.addEventListener('click',function(e){
  const summary=e.target.closest('.d2-faq details > summary');
  if(!summary) return;
  const current=summary.parentElement;
  requestAnimationFrame(function(){
    if(!current.open) return;
    document.querySelectorAll('.d2-faq details[open]').forEach(function(other){
      if(other!==current) other.open=false;
    });
  });
});

/* ---- next script block ---- */

function d2FaqFilter(filter){
  var buttons=document.querySelectorAll('.faq-category-strip .faq-cat');
  var items=document.querySelectorAll('.d2-faq details[data-cat]');
  buttons.forEach(function(btn){
    var active=btn.getAttribute('data-filter')===filter;
    btn.classList.toggle('active',active);
    btn.setAttribute('aria-selected',active?'true':'false');
  });
  items.forEach(function(item){
    var show=item.getAttribute('data-cat')===filter;
    item.hidden=!show;
    item.classList.toggle('faq-hidden',!show);
    item.style.setProperty('display',show?'block':'none','important');
    if(!show) item.open=false;
  });
}
document.addEventListener('DOMContentLoaded',function(){d2FaqFilter('booking');});

/* ---- next script block ---- */

(function(){
  function filterFaq(category){
    var buttons=document.querySelectorAll('.faq-cat');
    var items=document.querySelectorAll('.d2-faq details');
    for(var i=0;i<buttons.length;i++){
      var b=buttons[i], active=b.getAttribute('data-filter')===category;
      b.classList.toggle('active',active);
      b.setAttribute('aria-selected',active?'true':'false');
    }
    for(var j=0;j<items.length;j++){
      var item=items[j], show=item.getAttribute('data-cat')===category;
      item.hidden=!show;
      item.style.setProperty('display', show?'block':'none', 'important');
      if(!show) item.removeAttribute('open');
    }
  }
  window.d2FaqFilter=filterFaq;
  function init(){ filterFaq('booking'); }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();
})();

/* ---- next script block ---- */

(function(){
  function initMenu(){
    var btn = document.querySelector('.faq-header-menu');
    var nav = document.querySelector('.faq-header-nav');
    if(!btn || !nav) return;
    btn.addEventListener('click', function(e){
      e.stopPropagation();
      var isOpen = nav.classList.toggle('d2-menu-open');
      nav.hidden = !isOpen;
      btn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    });
    document.addEventListener('click', function(e){
      if(nav.classList.contains('d2-menu-open') && !nav.contains(e.target) && e.target !== btn){
        nav.classList.remove('d2-menu-open');
        nav.hidden = true;
        btn.setAttribute('aria-expanded','false');
      }
    });
    nav.addEventListener('click', function(e){
      if(e.target.tagName === 'A'){
        nav.classList.remove('d2-menu-open');
        nav.hidden = true;
        btn.setAttribute('aria-expanded','false');
      }
    });
  }
  function initHeaderOffset(){
    var header = document.querySelector('.faq-header');
    var wrap = document.querySelector('.faq-page');
    if(!header || !wrap) return;
    function apply(){
      wrap.style.paddingTop = header.offsetHeight + 'px';
    }
    apply();
    window.addEventListener('resize', apply);
  }
  if(document.readyState === 'loading'){
    document.addEventListener('DOMContentLoaded', function(){ initMenu(); initHeaderOffset(); });
  } else {
    initMenu();
    initHeaderOffset();
  }
})();

/* ---- next script block ---- */

(function(){
  var header=document.querySelector('.faq-header');
  if(!header) return;
  var lastY=window.scrollY||window.pageYOffset||0;
  var ticking=false;
  function onScroll(){
    var y=window.scrollY||window.pageYOffset||0;
    if(y>lastY && y>80){
      header.classList.add('d2-header-hidden');
    }else if(y<lastY){
      header.classList.remove('d2-header-hidden');
    }
    lastY=y<0?0:y;
    ticking=false;
  }
  window.addEventListener('scroll',function(){
    if(!ticking){
      window.requestAnimationFrame(onScroll);
      ticking=true;
    }
  },{passive:true});
})();

/* ---- next script block ---- */

(function(){
  var USERS_KEY='d2cabsUsers';
  var SESSION_KEY='d2cabsLoggedInUser';

  function getUsers(){ try{ return JSON.parse(localStorage.getItem(USERS_KEY))||[]; }catch(e){ return []; } }
  function saveUsers(u){ localStorage.setItem(USERS_KEY, JSON.stringify(u)); }
  function getSession(){ return localStorage.getItem(SESSION_KEY); }
  function setSession(phone){ localStorage.setItem(SESSION_KEY, phone); }
  function clearSession(){ localStorage.removeItem(SESSION_KEY); }

  var overlay=document.getElementById('d2AuthOverlay');
  var authBtn=document.getElementById('authBtn');
  var accountMenu=document.getElementById('d2AccountMenu');

  function openModal(panel){
    document.getElementById('d2LoginPanel').hidden=true;
    document.getElementById('d2SignupPanel').hidden=true;
    document.getElementById('d2ForgotPanel').hidden=true;
    document.getElementById(panel).hidden=false;
    overlay.classList.add('open');
  }
  function closeModal(){ overlay.classList.remove('open'); }

  function refreshHeader(){
    var session=getSession();
    if(session){
      var users=getUsers();
      var user=users.find(function(u){return u.phone===session;});
      authBtn.textContent = user ? user.name.split(' ')[0] : 'Account';
    } else {
      authBtn.textContent='Login';
    }
  }

  authBtn.addEventListener('click', function(){
    if(getSession()){
      accountMenu.classList.toggle('open');
    } else {
      openModal('d2LoginPanel');
    }
  });

  document.getElementById('d2AuthClose').addEventListener('click', closeModal);
  overlay.addEventListener('click', function(e){ if(e.target===overlay) closeModal(); });

  document.getElementById('showSignup').addEventListener('click', function(){ openModal('d2SignupPanel'); });
  document.getElementById('showLoginFromSignup').addEventListener('click', function(){ openModal('d2LoginPanel'); });
  document.getElementById('showForgot').addEventListener('click', function(){ openModal('d2ForgotPanel'); });
  document.getElementById('showLoginFromForgot').addEventListener('click', function(){ openModal('d2LoginPanel'); });

  // password show/hide using a single dynamically-swapped eye icon
  var EYE_OPEN='<path d="M1.5 12S5 5 12 5s10.5 7 10.5 7-3.5 7-10.5 7S1.5 12 1.5 12Z"></path><circle cx="12" cy="12" r="3"></circle>';
  var EYE_CLOSED='<path d="M2 2l20 20"></path><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 10.5 8 10.5 8a18.5 18.5 0 0 1-2.16 3.19m-3.35 2.98A9.12 9.12 0 0 1 12 20c-7 0-10.5-8-10.5-8a18.5 18.5 0 0 1 4.22-5.94"></path><path d="M14.12 14.12a3 3 0 1 1-4.24-4.24"></path>';
  document.querySelectorAll('.d2-pass-toggle').forEach(function(btn){
    btn.addEventListener('click', function(){
      var inp=document.getElementById(btn.getAttribute('data-target'));
      var icon=btn.querySelector('svg');
      if(inp.type==='password'){
        inp.type='text';
        icon.innerHTML=EYE_CLOSED;
      } else {
        inp.type='password';
        icon.innerHTML=EYE_OPEN;
      }
    });
  });

  document.getElementById('signupSubmitBtn').addEventListener('click', function(){
    var name=document.getElementById('signupName').value.trim();
    var phone=document.getElementById('signupPhone').value.trim();
    var email=document.getElementById('signupEmail').value.trim();
    var pass=document.getElementById('signupPassword').value;
    var err=document.getElementById('signupError');
    err.textContent='';
    if(!name||!email||!phone||!pass){ err.textContent='Please fill name, email, mobile number and password.'; return; }
    if(phone.length<10){ err.textContent='Enter a valid 10-digit mobile number.'; return; }
    var users=getUsers();
    if(users.find(function(u){return u.phone===phone;})){ err.textContent='An account with this mobile number already exists.'; return; }
    if(users.find(function(u){return u.email && u.email.toLowerCase()===email.toLowerCase();})){ err.textContent='An account with this email already exists.'; return; }
    users.push({name:name, phone:phone, email:email, password:pass});
    saveUsers(users);
    setSession(phone);
    refreshHeader();
    closeModal();
  });

  // Single field login: auto-detects phone or email
  document.getElementById('loginSubmitBtn').addEventListener('click', function(){
    var idVal=document.getElementById('loginIdentifier').value.trim();
    var pass=document.getElementById('loginPassword').value;
    var err=document.getElementById('loginError');
    err.textContent='';
    if(!idVal||!pass){ err.textContent='Please fill in all fields.'; return; }
    var users=getUsers();
    var user;
    var digitsOnly=idVal.replace(/\D/g,'');
    if(idVal.indexOf('@')>-1){
      user=users.find(function(u){return u.email && u.email.toLowerCase()===idVal.toLowerCase();});
    } else {
      user=users.find(function(u){return u.phone===digitsOnly.slice(-10);});
    }
    if(!user){ err.textContent='No account found. Please check your details or sign up.'; return; }
    if(user.password!==pass){ err.textContent='Incorrect password.'; return; }
    setSession(user.phone);
    refreshHeader();
    closeModal();
  });

  var otpStage=false;
  document.getElementById('forgotSubmitBtn').addEventListener('click', function(){
    var phone=document.getElementById('forgotPhone').value.trim();
    var err=document.getElementById('forgotError');
    var hint=document.getElementById('forgotHint');
    err.textContent='';
    if(!otpStage){
      if(!phone){ err.textContent='Please enter your mobile number.'; return; }
      if(phone.length<10){ err.textContent='Enter a valid 10-digit mobile number.'; return; }
    }
    var users=getUsers();
    var user=users.find(function(u){return u.phone===phone;});
    if(!otpStage){
      if(!user){ err.textContent='No account found with this number.'; return; }
      otpStage=true;
      document.getElementById('forgotOtpGroup').hidden=false;
      document.getElementById('forgotNewPassGroup').hidden=false;
      document.getElementById('forgotSubmitBtn').textContent='Reset Password';
      document.getElementById('forgotSub').textContent='Enter the OTP sent to your phone';
      hint.textContent='Demo mode: use OTP 1234 (in production this is sent via SMS).';
    } else {
      var otp=document.getElementById('forgotOtp').value.trim();
      var newPass=document.getElementById('forgotNewPassword').value;
      if(otp!=='1234'){ err.textContent='Incorrect OTP.'; return; }
      if(!newPass){ err.textContent='Enter a new password.'; return; }
      user.password=newPass;
      saveUsers(users);
      otpStage=false;
      document.getElementById('forgotOtpGroup').hidden=true;
      document.getElementById('forgotNewPassGroup').hidden=true;
      document.getElementById('forgotSubmitBtn').textContent='Send OTP';
      document.getElementById('forgotSub').textContent='Password reset! Please login.';
      hint.textContent='';
      openModal('d2LoginPanel');
    }
  });

  document.getElementById('d2LogoutBtn').addEventListener('click', function(){
    clearSession();
    accountMenu.classList.remove('open');
    refreshHeader();
  });

  document.addEventListener('click', function(e){
    if(!accountMenu.contains(e.target) && e.target!==authBtn){ accountMenu.classList.remove('open'); }
  });

  document.querySelectorAll('.d2-social-btn').forEach(function(btn){
    btn.addEventListener('click', function(){
      var provider=btn.getAttribute('data-provider');
      var note=btn.closest('.d2-auth-panel').querySelector('.d2-social-note');
      if(note){ note.textContent=provider+' login will be enabled once connected to a backend.'; }
    });
  });

  refreshHeader();
})();