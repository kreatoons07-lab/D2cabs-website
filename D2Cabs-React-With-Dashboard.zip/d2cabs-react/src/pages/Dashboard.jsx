import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../styles/dashboard.css';
import {
  BookingsIcon,
  GiftIcon,
  PinIcon,
  CardIcon,
  StarIcon,
  HelpIcon,
  SettingsIcon,
  LogoutIcon,
  CarIcon,
  PhoneIcon,
  MessageIcon,
  DownloadIcon,
  LockIcon,
  BanIcon,
  CloseIcon,
} from '../components/DashIcons';

// Same localStorage keys used by the login/signup flow in public/js/index.js —
// this page reads the real session instead of showing placeholder data.
const USERS_KEY = 'd2cabsUsers';
const SESSION_KEY = 'd2cabsLoggedInUser';

const BOOKING_TABS = [
  { key: 'active', label: 'Active' },
  { key: 'upcoming', label: 'Upcoming' },
  { key: 'completed', label: 'Completed' },
  { key: 'cancelled', label: 'Cancelled' },
];

// Bookings will come from the backend once it's connected. Kept as empty
// arrays here (not fake sample bookings) — the card markup already renders
// real fields (driver, rating, route, vehicle, payment) the moment an API
// starts filling these in.
const BOOKINGS = {
  active: [],
  upcoming: [],
  completed: [],
  cancelled: [],
};

function getUsers() {
  try {
    return JSON.parse(localStorage.getItem(USERS_KEY)) || [];
  } catch (e) {
    return [];
  }
}

function getSessionUser() {
  const phone = localStorage.getItem(SESSION_KEY);
  if (!phone) return null;
  return getUsers().find((u) => u.phone === phone) || null;
}

/* ---------------- Booking card (shared by Home preview + Bookings view) ---------------- */

function BookingCard({ booking }) {
  const initial = booking.driverName ? booking.driverName.trim().charAt(0).toUpperCase() : '?';
  const [showFareDetail, setShowFareDetail] = useState(false);
  return (
    <div className="d2dash-booking-card">
      {booking.status === 'cancelled' && (
        <span className="d2dash-booking-tag cancelled">
          Cancelled by {booking.cancelledBy || 'You'}
        </span>
      )}
      {booking.status === 'completed' && (
        <span className="d2dash-booking-tag completed">Completed</span>
      )}

      <div className="d2dash-booking-top">
        <div className="d2dash-avatar">{initial}</div>
        <div className="d2dash-booking-driver">
          <strong>{booking.driverName}</strong>
          <span>Booking ID: {booking.crn}</span>
        </div>
        {booking.rating && (
          <div className="d2dash-booking-rating">
            <StarIcon /> {booking.rating}
          </div>
        )}
      </div>

      <div className="d2dash-booking-route">
        <div className="pickup">{booking.pickup}</div>
        <div className="drop">{booking.drop}</div>
      </div>

      <div className="d2dash-booking-info">
        <div className="d2dash-booking-info-row">
          <span>Date</span>
          <b>{booking.date}</b>
        </div>
        <div className="d2dash-booking-info-row">
          <span>Time</span>
          <b>{booking.time}</b>
        </div>
        <div className="d2dash-booking-info-row">
          <span>Car Type</span>
          <b>{booking.carType}</b>
        </div>
        <div className="d2dash-booking-info-row">
          <span>Trip Type</span>
          <b>{booking.tripType}</b>
        </div>
        <div className="d2dash-booking-info-row">
          <span>Vehicle</span>
          <b>{booking.carModel}</b>
        </div>
        <div className="d2dash-booking-info-row">
          <span>Number Plate</span>
          <b>{booking.carNumber}</b>
        </div>
      </div>

      <button
        type="button"
        className="d2dash-booking-payment"
        onClick={() => setShowFareDetail((v) => !v)}
      >
        <span>
          Payment{' '}
          <span className={booking.paymentStatus === 'Paid' ? 'paid' : 'pending'}>
            ({booking.paymentStatus})
          </span>
        </span>
        <b>
          ₹{booking.fare} <span className="d2dash-fare-caret">{showFareDetail ? '▲' : '▼'}</span>
        </b>
      </button>

      {showFareDetail && (
        <div className="d2dash-fare-detail">
          <div className="d2dash-fare-detail-row">
            <span>Base Fare</span>
            <b>₹{booking.baseFare}</b>
          </div>
          <div className="d2dash-fare-detail-row">
            <span>Taxes &amp; Fees</span>
            <b>₹{booking.taxes}</b>
          </div>
          <div className="d2dash-fare-detail-row">
            <span>Payment Method</span>
            <b>{booking.paymentMethod}</b>
          </div>
          <div className="d2dash-fare-detail-row d2dash-fare-total">
            <span>Total</span>
            <b>₹{booking.fare}</b>
          </div>
        </div>
      )}

      {booking.status === 'active' && (
        <div className="d2dash-booking-actions d2dash-actions-3">
          <a className="icon-btn call-btn" href={`tel:${booking.driverPhone}`} aria-label="Call driver">
            <PhoneIcon /> Call
          </a>
          <button className="icon-btn message-btn" type="button" aria-label="Message driver">
            <MessageIcon /> Message
          </button>
          <button className="cancel-btn" type="button">Cancel Ride</button>
        </div>
      )}
      {booking.status === 'upcoming' && (
        <div className="d2dash-booking-actions">
          <button className="cancel-btn" type="button">Cancel</button>
          <button className="track-btn" type="button">Modify</button>
        </div>
      )}
      {booking.status === 'completed' && (
        <div className="d2dash-booking-actions">
          <button className="download-btn" type="button"><DownloadIcon /> Download Bill</button>
        </div>
      )}
    </div>
  );
}

/* ---------------- Real pickup/drop search — same Photon API + Indore
   bias the actual homepage booking form uses, so results match. ---------- */

const INDORE_LAT = 22.7196;
const INDORE_LON = 75.8577;

async function searchLocations(query) {
  const url = `https://photon.komoot.io/api/?q=${encodeURIComponent(query)}&lat=${INDORE_LAT}&lon=${INDORE_LON}&limit=6&lang=en`;
  const res = await fetch(url, { method: 'GET', mode: 'cors', headers: { Accept: 'application/json' } });
  if (!res.ok) throw new Error('search failed: ' + res.status);
  const data = await res.json();
  const features = (data.features || []).filter((f) => {
    const p = f.properties || {};
    return !p.countrycode || p.countrycode === 'IN';
  });
  return features.map((f) => {
    const p = f.properties || {};
    const coords = (f.geometry && f.geometry.coordinates) || [];
    const primary = p.name || p.street || p.district || 'Unknown';
    const area = p.city || p.district || p.state || 'India';
    const label = primary.toLowerCase() === area.toLowerCase() ? primary : `${primary}, ${area}`;
    return { label, lat: coords[1], lon: coords[0] };
  });
}

function LocationField({ kind, place, onChange }) {
  const [query, setQuery] = useState(place.label || '');
  const [suggestions, setSuggestions] = useState([]);
  const [open, setOpen] = useState(false);
  const timerRef = useRef(null);

  function handleInput(val) {
    setQuery(val);
    onChange({ label: val, lat: null, lon: null });
    clearTimeout(timerRef.current);
    if (val.trim().length < 3) {
      setSuggestions([]);
      setOpen(false);
      return;
    }
    timerRef.current = setTimeout(async () => {
      try {
        const results = await searchLocations(val.trim());
        setSuggestions(results);
        setOpen(results.length > 0);
      } catch (err) {
        setSuggestions([]);
        setOpen(false);
      }
    }, 350);
  }

  function pick(r) {
    setQuery(r.label);
    onChange({ label: r.label, lat: r.lat, lon: r.lon });
    setSuggestions([]);
    setOpen(false);
  }

  return (
    <div className={`d2dash-loc-field ${kind}`}>
      <div className="d2dash-loc-row">
        <div className="d2dash-loc-text">
          <label>{kind === 'pickup' ? 'From' : 'To'}</label>
          <input
            type="text"
            value={query}
            placeholder={kind === 'pickup' ? 'Enter Pickup Location' : 'Enter Drop Location'}
            onChange={(e) => handleInput(e.target.value)}
            onFocus={() => suggestions.length && setOpen(true)}
            onBlur={() => setTimeout(() => setOpen(false), 150)}
          />
        </div>
      </div>
      {open && (
        <div className="d2dash-loc-suggestions">
          {suggestions.map((r, i) => (
            <div key={i} onMouseDown={() => pick(r)}>{r.label}</div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ---------------- Bookings view ---------------- */

function BookingsView({ firstName }) {
  const [tab, setTab] = useState('active');
  const list = BOOKINGS[tab];
  const [pickup, setPickup] = useState({ label: '', lat: null, lon: null });
  const [drop, setDrop] = useState({ label: '', lat: null, lon: null });
  const navigate = useNavigate();

  const emptyText = {
    active: 'No active booking right now.',
    upcoming: 'No upcoming bookings.',
    completed: "You haven't completed a ride yet.",
    cancelled: 'No cancelled bookings.',
  }[tab];

  function handleBookRide() {
    // Hand the chosen pickup/drop off to the homepage booking form (same
    // keys public/js/index.js reads on load) so the customer continues
    // straight from where they left off instead of restarting the flow.
    localStorage.setItem(
      'd2cabsPendingLocations',
      JSON.stringify({
        fromLabel: pickup.label,
        fromLat: pickup.lat,
        fromLon: pickup.lon,
        toLabel: drop.label,
        toLat: drop.lat,
        toLon: drop.lon,
      })
    );
    navigate('/#homeScreen');
  }

  return (
    <section className="d2dash-bookings-section">
      <div className="d2dash-card d2dash-hero-card">
        <h2 className="d2dash-hero-greet">Hi, {firstName}</h2>
        <p className="d2dash-sub">Where are you going today?</p>
        <div className="d2dash-hero-route">
          <LocationField kind="pickup" place={pickup} onChange={setPickup} />
          <LocationField kind="drop" place={drop} onChange={setDrop} />
        </div>
        <button className="d2dash-book-btn" type="button" onClick={handleBookRide}>
          Book a Ride
        </button>
      </div>

      <div className="d2dash-tabs d2dash-tabs-4">
        {BOOKING_TABS.map((t) => (
          <button
            key={t.key}
            type="button"
            className={`d2dash-tab${tab === t.key ? ' active' : ''}`}
            onClick={() => setTab(t.key)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <div className="d2dash-empty">
          <div className="d2dash-empty-icon">{tab === 'cancelled' ? <BanIcon /> : <CarIcon />}</div>
          <p>{emptyText}</p>
          {(tab === 'active' || tab === 'upcoming') && (
            <Link className="d2dash-link-btn" to="/#homeScreen">
              Book a Ride
            </Link>
          )}
        </div>
      ) : (
        <div className="d2dash-booking-list">
          {list.map((b) => (
            <BookingCard key={b.id} booking={b} />
          ))}
        </div>
      )}
    </section>
  );
}

/* ---------------- Offers view ---------------- */

function OffersView() {
  return (
    <section className="d2dash-card">
      <h3>Offers &amp; Notifications</h3>
      <p className="d2dash-sub">Deals and updates on your rides</p>
      <div className="d2dash-empty">
        <div className="d2dash-empty-icon"><GiftIcon /></div>
        <p>No offers available right now. Check back soon!</p>
      </div>
    </section>
  );
}

/* ---------------- Simple empty-state sub-pages ---------------- */

function SimplePage({ title, children }) {
  return (
    <section className="d2dash-card">
      <h3>{title}</h3>
      {children}
    </section>
  );
}

function AccountSettings({ user, onSave }) {
  const [name, setName] = useState(user.name || '');
  const [email, setEmail] = useState(user.email || '');
  const [phone, setPhone] = useState(user.phone || '');
  const [savedMsg, setSavedMsg] = useState('');

  function handleUpdate(e) {
    e.preventDefault();
    const users = getUsers();
    const idx = users.findIndex((u) => u.phone === user.phone);
    if (idx === -1) return;
    users[idx] = { ...users[idx], name, email, phone };
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    // Phone doubles as the session key, so keep the session pointer in sync
    // if the user changed their number.
    localStorage.setItem(SESSION_KEY, phone);
    onSave(users[idx]);
    setSavedMsg('Saved!');
    setTimeout(() => setSavedMsg(''), 2000);
  }

  return (
    <section className="d2dash-card">
      <h3>Account Settings</h3>
      <p className="d2dash-sub">Personal Info</p>

      <form className="d2dash-settings-card" onSubmit={handleUpdate}>
        <label className="d2dash-field">
          <span>Name</span>
          <input type="text" value={name} onChange={(e) => setName(e.target.value)} required />
        </label>
        <label className="d2dash-field">
          <span>Email</span>
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label className="d2dash-field">
          <span>Phone Number</span>
          <input type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required />
        </label>
        <div className="d2dash-settings-footer">
          {savedMsg && <span className="d2dash-saved-msg">{savedMsg}</span>}
          <button className="d2dash-update-btn" type="submit">Update</button>
        </div>
      </form>
    </section>
  );
}

/* ---------------- Header: profile circle opens the FULL menu directly ---------------- */

function HeaderProfileMenu({ view, setView, firstName, onLogout }) {
  const [open, setOpen] = useState(false);

  const items = [
    { key: 'bookings', label: 'My Bookings', Icon: BookingsIcon },
    { key: 'offers', label: 'Offers', Icon: GiftIcon },
    { key: 'addresses', label: 'Saved Addresses', Icon: PinIcon },
    { key: 'payments', label: 'Payments', Icon: CardIcon },
    { key: 'reviews', label: 'Ratings & Reviews', Icon: StarIcon },
    { key: 'support', label: 'Help & Support', Icon: HelpIcon },
    { key: 'settings', label: 'Account Settings', Icon: SettingsIcon },
  ];

  return (
    <>
      <button
        className="d2dash-profile-icon-btn"
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Account menu"
      >
        <span className="d2dash-header-avatar">{firstName.charAt(0).toUpperCase()}</span>
      </button>

      {open && (
        <>
        <div className="d2dash-menu-backdrop" onClick={() => setOpen(false)} />
        <div className="d2dash-fullmenu">
          <div className="d2dash-fullmenu-top">
            <button
              className="d2dash-fullmenu-close"
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Close menu"
            >
              <CloseIcon />
            </button>
          </div>

          <div className="d2dash-fullmenu-list">
            {items.map((it) => (
              <button
                key={it.key}
                type="button"
                className={view === it.key ? 'active' : ''}
                onClick={() => {
                  setView(it.key);
                  setOpen(false);
                }}
              >
                <span className="d2dash-nav-icon"><it.Icon /></span> {it.label}
              </button>
            ))}
            <button
              type="button"
              className="d2dash-row-danger"
              onClick={() => {
                setOpen(false);
                onLogout();
              }}
            >
              <span className="d2dash-nav-icon"><LogoutIcon /></span> Log Out
            </button>
          </div>
        </div>
        </>
      )}
    </>
  );
}

/* ---------------- Root ---------------- */

export default function Dashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [checked, setChecked] = useState(false);
  const [view, setView] = useState('bookings');

  useEffect(() => {
    setUser(getSessionUser());
    setChecked(true);
  }, []);

  function handleLogout() {
    localStorage.removeItem(SESSION_KEY);
    navigate('/');
  }

  if (checked && !user) {
    return (
      <div className="d2dash">
        <header className="d2dash-header">
          <Link className="d2dash-brand" to="/">
            <span>D2Cabs</span>
          </Link>
        </header>
        <main className="d2dash-main">
          <div className="d2dash-card d2dash-empty">
            <div className="d2dash-empty-icon"><LockIcon /></div>
            <p>You need to log in to see your dashboard.</p>
            <Link className="d2dash-link-btn" to="/">
              Go to login
            </Link>
          </div>
        </main>
      </div>
    );
  }

  if (!checked) return null;

  const firstName = user.name ? user.name.split(' ')[0] : 'there';

  return (
    <div className="d2dash">
      <header className="d2dash-header">
        <Link className="d2dash-brand" to="/">
          <span>D2Cabs</span>
        </Link>
        <HeaderProfileMenu view={view} setView={setView} firstName={firstName} onLogout={handleLogout} />
      </header>

      <main className="d2dash-main d2dash-single-col">
        <div className="d2dash-col-main">
          {view === 'bookings' && <BookingsView firstName={firstName} />}
          {view === 'offers' && <OffersView />}
          {view === 'settings' && <AccountSettings user={user} onSave={setUser} />}
          {view === 'addresses' && (
            <SimplePage title="Saved Addresses">
              <div className="d2dash-empty"><p>No saved addresses yet.</p></div>
            </SimplePage>
          )}
          {view === 'payments' && (
            <SimplePage title="Payment Methods">
              <div className="d2dash-empty"><p>No payment method saved yet.</p></div>
            </SimplePage>
          )}
          {view === 'reviews' && (
            <SimplePage title="Ratings & Reviews">
              <div className="d2dash-empty"><p>You haven't rated a ride yet.</p></div>
            </SimplePage>
          )}
          {view === 'support' && (
            <SimplePage title="Help & Support">
              <a className="d2dash-row-btn" href="https://wa.me/918889633535" target="_blank" rel="noreferrer">
                Chat on WhatsApp <span className="arrow">›</span>
              </a>
              <Link className="d2dash-row-btn" to="/faq.html">
                FAQs <span className="arrow">›</span>
              </Link>
              <Link className="d2dash-row-btn" to="/contact.html">
                Contact Us <span className="arrow">›</span>
              </Link>
            </SimplePage>
          )}
        </div>
      </main>
    </div>
  );
}
